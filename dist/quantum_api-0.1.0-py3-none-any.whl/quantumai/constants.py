DEFAULT_BASE_URL = "https://api.example.com/v1"  # Your default endpoint
DEFAULT_TIMEOUT = 30
MAX_RETRIES = 3